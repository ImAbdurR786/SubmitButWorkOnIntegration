/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.dao;

import com.cg.collection.pp.bean.Customer;
import java.util.HashMap;

/**
 *
 * @author Raja
 */
public interface IBankDAO {
      public long createAccount(Customer customer);
      public HashMap<Long, Customer> getHashMap();
      public int depositeMoney(long accountNumber, int totalbal,String transaction);
      public int withdrawMoney(long accountNumbr, int totalbal,String transaction);
      public void fundTransfer(long fromaccountNo, long toaccountNo, int totalWithdraw, 
              int totalDeposite, String transaction1, String transaction2);
      public String printTransaction(long acountNo);
}
