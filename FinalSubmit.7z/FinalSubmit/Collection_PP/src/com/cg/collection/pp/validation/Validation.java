/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.collection.pp.validation;

import com.cg.collection.pp.dao.BankDAOImpl;
import com.cg.collection.pp.exception.BankException;
import com.cg.collection.pp.exception.NameException;
import com.cg.collection.pp.exception.NumberException;
import java.util.regex.Pattern;

/**
 *
 * @author Raja
 */
public class Validation {
    BankDAOImpl bankDao = new BankDAOImpl();
 
    public boolean isNameValid(String name){
       if(name.length()>4){
          if(Pattern.matches("([A-Z])*([a-z])*", name)){
        return true;
          }else {
        	  try {
              	throw new NameException("Name is not Valid");
              }catch(NameException ex) {
              	System.out.println(ex.getMessage());
              	return false;
              }
     }}
     else
       {
    	  try {
            	throw new NameException("Name length should be minimum 5");
            }catch(NameException ex) {
            	System.out.println(ex.getMessage());
            	return false;
            }
    }
    }   
  public boolean isNumberValid(String number) {
        if (number.matches("^[6-9][0-9]{9}$"))
            {
                return true;
            }
        else{
        try {
        	throw new NumberException("Number is not Valid");
        }catch(NumberException ex) {
        	System.out.println(ex.getMessage());
        	return false;
        }
        } 
  }
  
  public boolean isAccountValid(long toaccountNo) {
    if(bankDao.getHashMap().containsKey(toaccountNo)){
    return true;}
    else
    {throw new BankException("No such Account Exists");
    }    
    }
}
