import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Customer } from '../customer';
import { race } from 'q';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  bankService: BankService;
  customer: Customer;
  transaction: Transaction;
  customers: Customer[]=[];

  constructor(bankService: BankService) {
    this.bankService = bankService;
  }
  name: String;
  model : any ={};
  add(data: any) {

            let accountNo = Math.floor(Math.random() * 100) + 1000;
            let transId = Math.floor(Math.random() * 100) + 10;
            console.log(accountNo);
            this.customer = new Customer(accountNo, data.ename, data.epin, data.ephone, data.ebalance);
            this.transaction = new Transaction(transId, "Created Account", data.ebalance, accountNo);
            this.bankService.add(this.customer, this.transaction);
           }
         
        
  ngOnInit() {
  }

}
