package Capgemini.ParallelProjectSpringWithJPA;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import com.cg.project.bean.Customer;
//import com.cg.project.dao.UtilJava;
//import javax.persistence.EntityManager;
//
//import static org.junit.jupiter.api.Assertions.*;
//import org.junit.Test;
//import org.junit.jupiter.api.Assertions;
//
//public class Test {
//    	private EntityManager entityManager;
//
//	public Test() {
//		entityManager = UtilJava.getEntityManager();
//	}
//
//   
//	@Test
//	public void testShowBalance(long accountNo, String password)
//	{
//		entityManager.getTransaction().begin();
//		Customer customer = entityManager.find(Customer.class, accountNo);
//		
//		int observed= customer.getBalance();
//		int expected=1000;
//		Assertions.assertEquals(expected, observed);
//	}
//    
//}

