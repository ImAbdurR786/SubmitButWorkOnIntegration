package com.cg.project.client;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import com.cg.project.exception.BankException;
import com.cg.project.service.BankServiceImpl;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientUI {

	public static void main(String args[]) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	 	BankServiceImpl bankService = context.getBean("service", BankServiceImpl.class);
		// Accepting the input from the User.
		Scanner scanner = new Scanner(System.in);
		Customer customer;
		Transaction transaction;

		long accountNo;
		do {
			// Printing the menu bar.
			System.out.println("***************************************************************************");
			System.out.println("1. Create Account \n 2. Show Balance \n 3. Deposite "
					+ "\n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transcaction \n 7. Exit");
			System.out.println("***************************************************************************");
			System.out.println("Choose any option : ");
			int n = scanner.nextInt();

			// According to input from user the method is called using switch case.
			switch (n) {

			case 1:
				double a = Math.random() % 100; // Creating a random number
				accountNo = (long) (a * 1234567898); // Mutliplying with a dummy no. to get dummy account no.
				String name;
				do {
					System.out.println("Enter the Name(min of 5 char)");
					name = scanner.next();
				} while (!bankService.isNameValid(name));
				String number;
				do {
					System.out.println("Enter the Number");
					number = scanner.next();
				} while (!bankService.isNumberValid(number));
				
					System.out.println("Enter the pin.");
					int pin = scanner.nextInt();
					int balance;
					do {
						System.out.println("Enter the Balance to be deposit.(should be greater than 999)");
						balance = scanner.nextInt();
					} while (balance < 1000);

					customer = new Customer(name, number, pin, balance);
					customer.setAccountNo(accountNo);

					bankService.createAccount(customer);
					System.out.println("Your account is Created Successfully");
					System.out.println("Account number is :" + customer.getAccountNo());
				

				break;

			case 2:
				System.out.println("Enter the Account no.");
				Long accountNum = scanner.nextLong();
				if (bankService.contain(accountNum)) {
					System.out.println("Enter the pin");
					int pswrd = scanner.nextInt();
					if (bankService.checkPin(pswrd, accountNum)) {
						System.out.println("Your Balance is: " + bankService.showbalance(accountNum));
					} else {
						try {
							throw new BankException("Pin is wrong");
						} catch (BankException e) {
							System.out.println(e.getMessage());
						}
					}

				} else {
					try {
						throw new BankException("No Such Account Exist");
					} catch (BankException e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 3:

				System.out.println("Enter the account number");
				long accountNumber = scanner.nextLong();
				if (bankService.contain(accountNumber)) {
					System.out.println("Enter the pin");
					int pinNum = scanner.nextInt();
					if (bankService.checkPin(pinNum, accountNumber)) {
						int deposite;
						do {
							System.out.println("Enter the amount to be deposite (Should be greater than 0)");
							deposite = scanner.nextInt();
						} while (deposite < 0);
						transaction = new Transaction("Deposited", deposite);

						bankService.depositeBalance(accountNumber, deposite, transaction);

						System.out.println("Successfully Deposited" + deposite);
					} else {
						try {
							throw new BankException("Pin is wrong");
						} catch (BankException e) {
							System.out.println(e.getMessage());
						}
					}

				} else {
					try {
						throw new BankException("No Such Account Exist");
					} catch (BankException e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 4:

				System.out.println("Enter the account number");
				long accountNu = scanner.nextLong();

				if (bankService.contain(accountNu)) {
					System.out.println("Enter the PinNumber");
					int pinno = scanner.nextInt();
					if (bankService.checkPin(pinno, accountNu)) {
						int withdraw;
						do {
							System.out.println("Enter the amount to be withdraw (should be greater than 0)");
							withdraw = scanner.nextInt();
						} while (withdraw < 0);
						transaction = new Transaction("Withdraw", withdraw);

						int result = bankService.withdraw(accountNu, withdraw, transaction);
						if (result == 1) {
							System.out.println("Successfully Withdraw");
						} else {
							try {
								throw new BankException("Insufficient Balance");
							} catch (BankException e) {
								System.out.println(e.getMessage());
							}
						}
					} else {
						try {
							throw new BankException("Pin is wrong");
						} catch (BankException e) {
							System.out.println(e.getMessage());
						}
					}
				} else {
					try {
						throw new BankException("No Such Account Exist");
					} catch (BankException e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 5:

				System.out.println("Enter your account number.");
				Long fromAccountNo = scanner.nextLong();

				if (bankService.contain(fromAccountNo)) {
					System.out.println("Enter the Pin");
					int piin = scanner.nextInt();
					if (bankService.checkPin(piin, fromAccountNo)) {

						Long toAccountNo;
						do {
							System.out.println("Enter account number to transfer the money.");
							toAccountNo = scanner.nextLong();
						} while (!bankService.contain(toAccountNo));

						if (fromAccountNo.equals(toAccountNo)) {
							System.out.println("Both account number must be different");
						}

						else {
							int money;
							do {
								System.out.println("Enter the money to be transfer(greater than 0)");
								money = scanner.nextInt();
							} while (money < 0);

							Transaction transaction1 = new Transaction("Transfer to :" + toAccountNo, money);
							Transaction transaction2 = new Transaction("Recieved from :" + fromAccountNo, money);

							if (bankService.fundTransfer(fromAccountNo, toAccountNo, money, transaction1,
									transaction2) == 1) {
								System.out.println("Successfully Transfer");
							} else {
								try {
									throw new BankException("Insufficient Balance");
								} catch (BankException e) {
									System.out.println(e.getMessage());
								}
							}
						}
					} else {
						try {
							throw new BankException("Pin is wrong");
						} catch (BankException e) {
							System.out.println(e.getMessage());
						}
					}
				} else {
					try { 
						throw new BankException("No Such Account Exist");
					} catch (BankException e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 6:
				System.out.println("Enter the Account Number");
				long transAccNo = scanner.nextLong();

				if (bankService.contain(transAccNo)) {
					System.out.println("Enter the Pin");
					int pin1 = scanner.nextInt();
					if (bankService.checkPin(pin1, transAccNo)) {
						List<Transaction> list = bankService.printTransaction(transAccNo);
						System.out.println("Your Transaction are:");
						System.out.println("Trans_ID    Trans_Type  Trans_balance");
						for (Transaction trans : list) {
							System.out.println(trans.getId() + "	" + trans.getType() + "		" + trans.getBalance());
						}
					} else {
						try {
							throw new BankException("Pin is wrong");
						} catch (BankException e) {
							System.out.println(e.getMessage());
						}
					}
				} else {
					try {
						throw new BankException("No Such Account Exist");
					} catch (BankException e) {
						System.out.println(e.getMessage());
					}
				}
				break;

			case 7:
				System.exit(0);
			default:
				System.out.println("Enter the valid choice");

			}
		} while (true);
	}
}