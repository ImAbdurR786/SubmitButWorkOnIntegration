/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.cg.project.bean.Customer;
import com.cg.project.dao.UtilJava;
import javax.persistence.EntityManager;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestClass {

    private EntityManager entityManager;
    private Long acc;

    public TestClass() {
        entityManager = UtilJava.getEntityManager();
        acc = Long.valueOf(136935783);
    }

    @Test
    public void testShowBalance() {
        Customer customer = entityManager.find(Customer.class, acc);
        int observed = customer.getBalance();
        int expected = 44435;
        assertEquals(expected, observed);
    }

//    @Test
//    public void testgetCustomerByAccountNo() {
//        Customer actualCustomer = entityManager.find(Customer.class, Long.valueOf(136935783));
//        Customer expectedCustomer = new Customer("Rahman", "9876543334", 234, 44435);
//        expectedCustomer.setAccountNo(acc);
//        System.out.println(expectedCustomer);
//        assertEquals(expectedCustomer, actualCustomer);
//    }
    
    @Test
    public void withdrawBalance() {
        Customer customer = entityManager.find(Customer.class, Long.valueOf(136935783));
        customer.setBalance(customer.getBalance() - 100);
        int actualBalance = customer.getBalance();
        int expectedBalance = 44335;
        assertEquals(expectedBalance, actualBalance);
    }

    @Test
    public void depositeBalance() {
        Customer customer = entityManager.find(Customer.class, Long.valueOf(136935783));
        customer.setBalance(customer.getBalance() + 200);
        int actualBalance = customer.getBalance();
        int expectedBalance = 44535;
        assertEquals(expectedBalance, actualBalance);

    }

}
