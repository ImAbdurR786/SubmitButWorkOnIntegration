package com.cg.project.dao;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

public class BankDAOImpl {
    
        EntityManager entityManager =UtilJava.getEntityManager();
    
    	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

    	public void beginTransaction() {
		entityManager.getTransaction().begin();
        }
    
        public Customer getCustomerByAccountNo(Long accountNum){
          Customer customer = entityManager.find(Customer.class, accountNum);
          return customer;
        }
        
        public void createAccount(Customer customer) {
                entityManager.persist(customer);
        }
 
        public int showbalance(Long showaccountNo) {
        Customer customer = entityManager.find(Customer.class, showaccountNo);
        return customer.getBalance();
        }
    
       
        public void depositeBalance(Customer customer, Transaction transaction) {
         entityManager.merge(customer);
         entityManager.merge(transaction);
        }
    
       public void withdrawBalance(Customer customer, Transaction transaction) {
        entityManager.merge(customer);
        entityManager.merge(transaction);
       }
       
        public void fundTransfer(Customer customer1, Customer customer2, Transaction transaction1, Transaction transaction2) {
         entityManager.merge(customer1);
         entityManager.merge(customer2);
         entityManager.merge(transaction1);
         entityManager.merge(transaction2);
        }

   
        public List<Transaction> printTransaction(long transAccNo) {
        Query query = entityManager.createQuery("select c from Transaction c where c.customer.accountNo=" + transAccNo);
        return query.getResultList();
        }
   
    public boolean conatin(Long accountNo) {
        Customer customer = entityManager.find(Customer.class,accountNo);
        if(customer==null)
            return false;
        else
           return true;
    }

    public boolean checkPin(int pin, Long accountNo) {
    Customer customer = entityManager.find(Customer.class, accountNo);
    if(customer.getPin() == pin){
    return true;}
    else
        return false;
    }   
  
}
