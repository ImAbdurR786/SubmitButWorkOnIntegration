package com.cg.project.exception;

public class NumberException extends RuntimeException {

    public NumberException() {
	}
    
	public NumberException(String message) {
        super(message);
    }
    
}
