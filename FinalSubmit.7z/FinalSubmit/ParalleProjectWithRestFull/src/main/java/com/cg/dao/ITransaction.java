package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entities.Transacations;

public interface ITransaction extends JpaRepository<Transacations, Long> {

	@Query("from Transacations where accountNo = ?1")
	List<Transacations> printTransaction( Long accNo);

//	@Query("from Transacations where accNo=?1")
//	List<Transacations> printTransaction(Long accNo);
}
