package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Table(name = "custm")
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long accNo;

	@NotEmpty(message = "Please provide a name")
	private String name;

	private String pin;

	@Min(value = 1, message = "Atleast initial balance should be greater than zero")
	private Double bal;

	private Long mobNo;

	public Customer() {
	}

	public Customer(String name, String pin, Double bal, Long mobNo) {

		this.pin = pin;
		this.name = name;
		this.bal = bal;
		this.mobNo = mobNo;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getBal() {
		return bal;
	}

	public void setBal(Double bal) {
		this.bal = bal;
	}

	public Long getMobNo() {
		return mobNo;
	}

	public void setMobNo(Long mobNo) {
		this.mobNo = mobNo;
	}

	@Override
	public String toString() {
		return "Customer{" + "accNo=" + accNo + ", name=" + name + ", pin=" + pin + ", bal=" + bal + ", mobNo=" + mobNo
				+ '}';
	}

}
