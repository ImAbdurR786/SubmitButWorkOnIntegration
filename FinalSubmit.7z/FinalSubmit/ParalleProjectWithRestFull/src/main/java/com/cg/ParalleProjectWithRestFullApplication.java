package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParalleProjectWithRestFullApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParalleProjectWithRestFullApplication.class, args);
	}

}
