export class Transactions {
    transNo : number;
    transType : String;
    Balance : number;
    accountNo : number;
    constructor(transNo: number, transType:String, Balance: number, accountNo:number){
        this.transNo = transNo;
        this.transType = transType;
        this.Balance = Balance;
        this.accountNo = accountNo;
    }
}
