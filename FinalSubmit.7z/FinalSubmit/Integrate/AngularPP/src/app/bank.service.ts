import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transactions } from './transaction';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  ShowCustomer: Customer;
  httpClient: HttpClient;
  constructor(httpClient: HttpClient) {
    this.httpClient = httpClient;
   }

  add(customer: Customer): Observable<Customer> {
   return this.httpClient.post<Customer>('http://localhost:8086/bankController/createAccount',customer); 
  }

  showBalance(data: any):Observable<String> {
      return this.httpClient.get<String>("http://localhost:8086/bankController/showBalance/"+data.accountno+"/"+data.pin);
  }

  depositeBalance(data: any): Observable<any> {
    return this.httpClient.put<String>("http://localhost:8086/bankController/deposit/"+data.depaccountno+"/"+data.deppin+"/"+data.depbalance,"");
  }

  withdrawBalance(data: any) : Observable<any>{
    return this.httpClient.put<String>("http://localhost:8086/bankController/withdraw/"+data.withdrawaccountno+"/"+data.withdrawpin+"/"+data.withdrawbalance,"");
  }

  transferBalance(data: any) :Observable<any>{
    return this.httpClient.put<String>("http://localhost:8086/bankController/fundTransfer/"
    +data.fromaccountno+"/"+data.frompin+"/"+data.transferbalance+"/"+data.toaccountNo,"");
  }
  
  printTransaction(data: any) : Observable<any>{
  // return null;
    return this.httpClient.get("http://localhost:8086/bankController/printTransactions/"+data.transaccountno+"/"+data.transpin);
  }
}
