import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transactions } from '../transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  bankService: BankService;
  showTransaction: boolean = true;

  constructor(bankService: BankService) {
    this.bankService = bankService;
  }


  showTrans() {
    this.showTransaction = !this.showTransaction;
  }

  transactions : Transactions[] =[];
  
  printTransaction(data: any) {
    this.bankService.printTransaction(data).subscribe(
       data=>{
  
       }
     );
  }

  ngOnInit() {
  }

}
