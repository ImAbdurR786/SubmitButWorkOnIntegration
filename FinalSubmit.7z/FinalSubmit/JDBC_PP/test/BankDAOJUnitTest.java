
import com.project.jdbc.dao.BankDAOImpl;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class BankDAOJUnitTest {

    BankDAOImpl bankDao;

    @Before
    public void BeforeAllMethod() {
        bankDao = new BankDAOImpl();
    }
    //655849335 Abdur                          9876543211       pin: 123      bal: 2345
    @Test
    public void TestGetAccountDetails() throws SQLException {
        ResultSet accountDetails = bankDao.getAccountDetails(Long.valueOf(655849335));
        Long actual = null;
        while(accountDetails.next()){
        actual = accountDetails.getLong(1);
        }
        Long expected = Long.valueOf(655849335);
        assertEquals(expected, actual);
    }

    @Test
    public void TestwithdrawBalance() throws SQLException {
        ResultSet accountDetails = bankDao.getAccountDetails(Long.valueOf(655849335));
        int actual = 0;
        while(accountDetails.next()){
        actual = accountDetails.getInt(5);
        actual = actual - 100;
        }
        int expected = 2245;
        assertEquals(expected, actual);
    }
    
    @Test
    public void TestdepositeBalance() throws SQLException {
        ResultSet accountDetails = bankDao.getAccountDetails(Long.valueOf(655849335));
        int actual = 0;
        while(accountDetails.next()){
        actual = accountDetails.getInt(5);
        actual = actual + 100;
        }
        int expected = 2445;
        assertEquals(expected, actual);
    }
}
