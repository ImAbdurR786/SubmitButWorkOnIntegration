package com.project.jdbc.service;

import java.sql.ResultSet;

import com.project.jdbc.bean.Customer;
import com.project.jdbc.bean.Transaction;

public interface IBankService {

	public void createAccount(Customer customer, Transaction transaction);

	public int showbalance(Long accountNum);

	public boolean contain(Long accountNum);

	public boolean checkPin(int pin, Long accountNum);

	public void depositeBalance(long accountNumber, int deposite, Transaction transaction);

	public int withdraw(long accountNum, int withdraw, Transaction transaction);

	public int fundTransfer(Long fromAccountNo, Long toAccountNo, int money, Transaction transaction1,
			Transaction transaction2);

	public ResultSet printTransaction(long transAccNo);

}
