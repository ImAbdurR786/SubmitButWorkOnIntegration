package com.project.jdbc.exception;

public class NumberException extends RuntimeException{

    public NumberException(String message) {
      super(message);
    }
  
}
