package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Transacations;
import com.cg.exception.AccountNotFoundException;

public interface IService {

	Customer createAccount(Customer customer, Transacations trans) throws AccountNotFoundException;

	Double showBalance(Long accNo, String pin) throws AccountNotFoundException;

	Double deposit(Long accNo, Double amt, String pin, Transacations trans) throws AccountNotFoundException;

	Double withdraw(Long accNo, Double amt, String pin, Transacations trans) throws AccountNotFoundException;

	Double fundTransfer(Long accNo, String pin, Double amt, Long accNo1, Transacations trans1, Transacations trans2)
			throws AccountNotFoundException;

	List<Transacations> printTransaction(Long accNo, String pin) throws AccountNotFoundException;
}
