package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBankDao;
import com.cg.dao.ITransaction;
import com.cg.entities.Customer;
import com.cg.entities.Transacations;
import com.cg.exception.AccountNotFoundException;

@Service

public class ServiceImpl implements IService {
	@Autowired
	IBankDao bankDao;

	@Autowired
	ITransaction transactionDetails;

	@Override
	public Customer createAccount(Customer customer, Transacations trans) throws AccountNotFoundException {
		if (customer.getBal() == null || customer.getBal() <= 0) {
			throw new AccountNotFoundException("Atleast initial balance should be more than zero");
		} else {

			transactionDetails.save(trans);
			bankDao.save(customer);
			return bankDao.findById(customer.getAccNo()).get();
		}
	}

	@Override
	public Double showBalance(Long accNo, String pin) throws AccountNotFoundException {
		if (!bankDao.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			if (bankDao.findById(accNo).get().getPin().equals(pin)) {
				return bankDao.findById(accNo).get().getBal();
			} else {
				throw new AccountNotFoundException("Invalid Pin Number");
			}
		}
	}

	@Override
	public Double deposit(Long accNo, Double amt, String pin, Transacations trans) throws AccountNotFoundException {

		Optional<Customer> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			Customer tempEntity = bank.get();
			if (bank.get().getPin().equals(pin)) {
				tempEntity.setBal(bank.get().getBal() + amt);
				bankDao.save(tempEntity);

				transactionDetails.save(trans);
				return showBalance(accNo, pin);
			} else {
				throw new AccountNotFoundException("Invalid pin!!!");
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double withdraw(Long accNo, Double amt, String pin, Transacations trans) throws AccountNotFoundException {
		Optional<Customer> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			if (bank.get().getPin().equals(pin)) {
				if (amt > showBalance(accNo, pin)) {
					throw new AccountNotFoundException("Low balance");
				} else {
					Customer tempEntity = bank.get();
					tempEntity.setBal(bank.get().getBal() - amt);
					bankDao.save(tempEntity);
					transactionDetails.save(trans);
					return showBalance(accNo, pin);
				}
			} else {
				throw new AccountNotFoundException("Invalid pin!!!");
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double fundTransfer(Long accNo, String pin, Double amt, Long accNo1, Transacations trans1,
			Transacations trans2) throws AccountNotFoundException {
		Optional<Customer> senderAccount = bankDao.findById(accNo);
		Optional<Customer> reciverAccount = bankDao.findById(accNo1);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {
			if (senderAccount.get().getPin().equals(pin)) {

				if (senderAccount.get().getBal() > amt) {
					Customer sender = senderAccount.get();
					sender.setBal(senderAccount.get().getBal() - amt);
					bankDao.save(sender);

					Customer reciver = reciverAccount.get();
					reciver.setBal(reciverAccount.get().getBal() + amt);
					bankDao.save(reciver);

					transactionDetails.save(trans1);

					transactionDetails.save(trans2);

					return showBalance(accNo, pin);
				} else {
					throw new AccountNotFoundException("InSufficient Balance!!!");
				}
			} else {
				throw new AccountNotFoundException("Invalid Pin!!!");
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public List<Transacations> printTransaction(Long accNo, String pin) throws AccountNotFoundException {
//		Optional<Customer> bank = bankDao.findById(accNo);
//		if (bank.isPresent()) {
//			if (bank.get().getPin().equals(pin)) {
//				
				return transactionDetails.printTransaction(accNo);
//			} else {
//				throw new AccountNotFoundException("Invalid Pin!!!");
//			}
//		} else {
//			throw new AccountNotFoundException("Invalid account number!!!");
//		}
//	
	}
}
