package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transac")
public class Transacations {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer transNo;
	private String transType;
	private Double Balance;

	private Long accountNo;

	public Transacations() {
		super();
	}

	public Transacations(String transType, Double Balance) {
		super();
		this.transType = transType;
		this.Balance = Balance;
	}

	public Integer getTransNo() {
		return transNo;
	}

	public void setTransNo(Integer transNo) {
		this.transNo = transNo;
	}

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public Double getBalance() {
		return Balance;
	}

	public void setBalance(Double Balance) {
		this.Balance = Balance;
	}

	@Override
	public String toString() {
		return "Transacation{" + "transNo=" + transNo + ", accno=" + accountNo + ", transType=" + transType
				+ ", Balance=" + Balance + '}';
	}

}
