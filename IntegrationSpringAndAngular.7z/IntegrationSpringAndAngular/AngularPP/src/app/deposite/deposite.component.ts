import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-deposite',
  templateUrl: './deposite.component.html',
  styleUrls: ['./deposite.component.css']
})
export class DepositeComponent implements OnInit {

  bankService: BankService;
  
  constructor(bankService: BankService) {
    this.bankService = bankService;
   }

  depositeBalance(data: any){
    this.bankService.depositeBalance(data).subscribe
    (data1=>{
      alert("Deposited "+ data.depbalance+"\n"+
        "updated balance "+ data1);
    });
  }
  ngOnInit() {
  }

}