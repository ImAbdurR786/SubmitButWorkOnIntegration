import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  bankService: BankService;
  withdrawString: String;
  constructor(bankService: BankService) { 
    this.bankService = bankService;
  }

  withdrawBalance(data: any){
   this.bankService.withdrawBalance(data).subscribe(
    data1=>{
      alert("Withdraw "+ data.withdrawbalance+"\n"+
        "updated balance "+ data1);
    });
  }
  
  ngOnInit() {
  }

}
