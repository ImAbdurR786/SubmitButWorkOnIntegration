export class Customer {
    accNo:  number;
    name: String;
    pin: number;
    mobNo : number;
    bal: number;

    constructor(name:String,pin:number,mobNo:number, bal:number){
    this.name = name;
    this.pin = pin;
    this.mobNo = mobNo;
    this.bal = bal;
}

}
