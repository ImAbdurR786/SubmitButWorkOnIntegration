import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transacations } from '../transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  bankService: BankService;
  showTransaction: boolean = true;
  transaction: Transacations[];
  constructor(bankService: BankService) {
    this.bankService = bankService;
  }


  showTrans() {
    this.showTransaction = !this.showTransaction;
  }
  printTransaction(data: any) {
    this.bankService.printTransaction(data).subscribe(
       data=>{
        this.transaction = data;
       }
     );
  }

  ngOnInit() {
  }

}
