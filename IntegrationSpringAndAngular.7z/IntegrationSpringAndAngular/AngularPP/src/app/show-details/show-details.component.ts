import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-show-details',
  templateUrl: './show-details.component.html',
  styleUrls: ['./show-details.component.css']
})
export class ShowDetailsComponent implements OnInit {

  bankService: BankService;
  getDetails: Customer;
  balance:DoubleRange;
  shown: boolean = true;
  constructor(bankServie: BankService) {
    this.bankService = bankServie;
   }

   showBalance(data:any){
    this.bankService.showBalance(data).subscribe
    (data=>{
      this.balance = data;
    });
   }

   show(){
     this.shown = !this.shown;
   }

   ngOnInit() {
   }
}
