import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transacations } from './transaction';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  ShowCustomer: Customer;
  httpClient: HttpClient;
  constructor(httpClient: HttpClient) {
    this.httpClient = httpClient;
   }

  add(customer: Customer): Observable<Customer> {
   return this.httpClient.post<Customer>('http://localhost:8086/bankController/createAccount',customer); 
  }

  showBalance(data: any):Observable<DoubleRange> {
    return this.httpClient.get<any>("http://localhost:8086/bankController/showBalance/"+data.accountno+"/"+data.pin);
  }

  depositeBalance(data: any): Observable<DoubleRange> {
    return this.httpClient.put<any>("http://localhost:8086/bankController/deposit/"+data.depaccountno+"/"+data.deppin+"/"+data.depbalance,"");
  }

  withdrawBalance(data: any) : Observable<DoubleRange>{
    return this.httpClient.put<any>("http://localhost:8086/bankController/withdraw/"+data.withdrawaccountno+"/"+data.withdrawpin+"/"+data.withdrawbalance,"");
  }

  transferBalance(data: any) :Observable<DoubleRange>{
    return this.httpClient.put<any>("http://localhost:8086/bankController/fundTransfer/"
    +data.fromaccountno+"/"+data.frompin+"/"+data.transferbalance+"/"+data.toaccountno,"");
  }
  
  printTransaction(data: any):Observable<any[]> {
    return this.httpClient.get<any[]>("http://localhost:8086/bankController/printTransactions/"+data.transaccountno+"/"+data.transpin);
  }
}
